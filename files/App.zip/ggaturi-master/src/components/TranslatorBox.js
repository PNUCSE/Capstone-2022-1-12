import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const TranslatorBox = ({ region, language }) => {

  return (
    <View style={styles.section}>

        <View style={styles.region}>
            <Text style={styles.regionText}>{region}</Text>
        </View>

        <Text style={{...styles.midText, marginTop: 12}}>{language}</Text>

    </View>
  )
}

const styles = StyleSheet.create({
  section: {
    width: '100%',
    paddingHorizontal: 16,
    paddingVertical: 18,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderColor: '#E3DDFF',
    borderWidth: 1.5,
    height: 200
  },
  region: {
    backgroundColor: '#7B6CD1',
    borderRadius: 10,
    width: 80,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  regionText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  midText: {
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 20,
  },
})

export default TranslatorBox;