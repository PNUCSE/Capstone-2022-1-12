import { createStackNavigator } from '@react-navigation/stack';
import * as React from 'react';

import HomeScreen from '../screens/HomeScreen';

const Stack = createStackNavigator();

const MainNavi = () => {

    return (
        <Stack.Navigator>

            <Stack.Screen 
                name="HomeScreen" 
                component={HomeScreen}
                options={{
                    headerShown: false
                }} 
            />

        </Stack.Navigator>
    );
}

export default MainNavi;