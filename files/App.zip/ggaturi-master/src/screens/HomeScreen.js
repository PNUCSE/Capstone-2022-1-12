import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, SafeAreaView, View, Image, Text, ScrollView, Pressable } from "react-native";
import { Audio } from 'expo-av';
import { Entypo } from '@expo/vector-icons';
import Lottie from 'lottie-react-native';

import TranslatorBox from "../components/TranslatorBox";

const HomeScreen = () => {

  const [recording, setRecording] = useState();
  const [slang, setSlang] = useState("");
  const [standard, setStandard] = useState("");

  const [visible, setVisible] = useState(false);

  const StartRecording = async () => {
    try {
      const permission = await Audio.requestPermissionsAsync();

      if (permission.status === "granted") {
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: true,
          playsInSilentModeIOS: true
        });
        
        const { recording } = await Audio.Recording.createAsync(
          Audio.RECORDING_OPTIONS_PRESET_LOW_QUALITY
        );

        setRecording(recording);
        setSlang("");
        setStandard("");
      }
    } catch (err) {
      console.error('Failed to start recording', err);
    }
  }

  const StopRecording = async () => {
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: false
      });

      setRecording(undefined);
      setVisible(true);
      await recording.stopAndUnloadAsync();
      await SetLanguage(recording.getURI());
      setVisible(false);
    } catch (err) {
      console.log(err)
    }
  }

  const SetLanguage = async (result) => {
    try {
      const url = 'http://164.125.252.182:8009/file_upload'
      const formData = new FormData()
  
      formData.append('file', {
        uri: result,
        type: 'wav',
        name: 'file.wav'
      })

      const options = {
        method: 'POST',
        body: formData,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'multipart/form-data',
        },
      };
  
      const response = await fetch(url, options);
  
      if (response && response.ok) {
        const data = await response.json();
        console.log(data)
        setSlang(data.text)
        setStandard(data.text2)
      }
    } catch (err) {
      console.log(err)
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={{ ...styles.section, ...styles.rowContainer }}>
          <Image
            style={{ height: 50, width: 50 }}
            source={require("../assets/images/bird.png")}
          />
          <Text style={{...styles.bigText, paddingLeft: 20}}>사투리를 음성으로 녹음해주세요.</Text>
        </View>

        <View style={{ ...styles.section, alignItems: "center" }}>
          <TranslatorBox region="경상도" language={slang} />
          <Entypo
            name="cycle"
            size={40}
            color="#7B6CD1"
            style={{ marginVertical: 8 }}
          />
          <TranslatorBox region="표준어" language={standard} />
        </View>

        <Pressable style={{alignItems: "center", marginTop: 20}} onPress={recording ? StopRecording : StartRecording}>
          <Image
            style={{ height: 80, width: 80 }}
            source={recording ? require("../assets/images/stop.png") : require("../assets/images/play.png")}
          />
        </Pressable>

      </ScrollView>
      { visible &&
        <Lottie style={styles.overlay} source={require('../assets/Loader.json')} autoPlay loop />
      }
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    backgroundColor: "#F4F3FF",
  },
  section: {
    padding: 20,
  },
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  bigText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#2B2C31",
  },
  midText: {
    fontSize: 16,
    fontWeight: "400",
    color: "#2B2C31",
  },
  overlay: {
    flex: 1,
    position: 'absolute',
    left: 0,
    top: 0,
    opacity: 0.8,
    backgroundColor: 'black'
  } 
});

export default HomeScreen;
