import React from 'react';
import { View } from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MainNavi from './src/navigation/MainNavi';

const Stack = createStackNavigator();

export default function App() {

  return (
    <NavigationContainer>
      <View style={{ paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0 }} />
      <Stack.Navigator initialRouteName="MainNavi">
        <Stack.Screen
          name="MainNavi"
          component={MainNavi}
          options={{headerShown: false, animationEnabled: false}}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
