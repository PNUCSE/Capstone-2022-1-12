from config import myConfig
from transformer import build_model, do_predict

def main_module(str):
    ## 모델 불러오기
    vocab, config = myConfig()
    model = build_model(config)
    model.load_weights("wish_translation.hdf5")

    ### input msg 주면 예측
    input_msg = str

    result = do_predict(model, 20, input_msg)
    print(f"output > {result}")

    return result

if __name__ == "__main__":
    main_module("로렐라이 가제이")