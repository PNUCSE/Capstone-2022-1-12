<실행시>
cd ~/Desktop/flask_test_folder
source ./venv/bin/activate
python3 STT_server.py

<종료시>
Ctrl+ C
deactivate

<대략적인 설명>	
STT_server.py의 역할
구글 STT_API 로 음성인식을 수행하는 서버를 실행한다.

main.py, transformer.py, config.py는 텐서플로우 기반 사투리 번역 프로그램의 모듈들이며
이름이 main.py이지만 혼동이 없었으면 한다.

위 모듈은 STT_server에서 함수를 활용하여 돌아간다.


<구글 API 사용 권한 키 발급>
폴더 'google_stt_json_key' 에 구글 [stt api json키 파일]을 넣어야한다.
경로는 STT_server.py 내부 코드에서 지시해주어야 하며 현재는 작동하지 않는 예시 파일이 적혀있다.
구글 클라우드 콘솔에서 프로젝트를 생성한 후 Cloud Speech-to-Text API 사용, 
키를 발급 받아, 형식에 맞추어서 폴더 안에 넣어 놓자. 
TT_server.py 내부 코드에서 경로를 지시해주어야 하는 걸 잊지 말자.
