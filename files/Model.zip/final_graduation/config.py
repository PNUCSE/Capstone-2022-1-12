import sentencepiece as spm

class Config(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__

def myConfig():
    vocab = spm.SentencePieceProcessor()
    vocab.load(f"corpus.model")

    config = Config({"d_model":256 , "n_head": 8, "d_head": 64, "dropout": 0.1, "d_ff": 512, "layernorm_epsilon": 0.001, "n_layer": 3, "n_seq": 256, "n_vocab": 0, "i_pad": 0})
    config.n_vocab = len(vocab)
    config.i_pad = 0

    return vocab, config