import csv

word_array = list()
f = open("Saturi_file.csv", 'r', encoding='utf-8-sig')
rea = csv.reader(f)
for row in rea:
    word_array.append(row[0])
f.close

print(word_array)